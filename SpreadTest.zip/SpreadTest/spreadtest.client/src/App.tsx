
import './App.css';
import Package from './SpreadClient';


function App() {


  

 

    return (
        <div>
            <h1 id="tableLabel">Spread Sheet</h1>
           <Package />
        </div>
    );

}

export default App;