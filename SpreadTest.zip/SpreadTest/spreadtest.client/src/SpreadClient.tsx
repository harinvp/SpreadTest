import { useEffect, useRef, useState } from 'react';
import '@mescius/spread-sheets/styles/gc.spread.sheets.excel2013white.css';
import '@mescius/spread-sheets-react';
import * as GC from '@mescius/spread-sheets';
import { SpreadSheets } from '@mescius/spread-sheets-react';
import styles from '../src/spreadclient.module.css';
import CircularProgress from '@mui/material/CircularProgress';
GC.Spread.Sheets.LicenseKey = "Level Crossing Removal Project,E956459693358441#B131OKwEGd8ZVbDt6RRFTS6VXekZUbrlVeoxkaNNFRit4byNHRupGcNhHWnZEVrRHULhkVqlmSZZWbSplMIZ6cxIXeKtGWGNUOolzZJ34RZRHep3iQsxmaxoEMutUcERXeCpWU7RHUPNURzAnbzEjbTpnMwhEeZ5kQkBnWyZEZJpkTkZ5c5VleiJ5NVdUVrV5LOJ5bvoHR95WYWZ5SKp4QthTWQVFWGJnNo34LX3yYRRUb09WT8omRi5kb5s6VDBXejJ5MxJ7Y4RURGpmT6MVeld5Upp7L7ZVWQd7cnJUcCRGTQZWOINTROVGS82UU7wGOt3WRItyZzcGWCN4MOlkUZlWUuR7Yod4Np3mdQl5ZTdEZMNnWiojITJCLiQ4MzgDRFNTMiojIIJCL9ITM9ETN5czM0IicfJye35XX3JCSJpkQiojIDJCLigTMuYHITpEIkFWZyB7UiojIOJyebpjIkJHUiwiIwEzMzYDMgQDM6ATNyAjMiojI4J7QiwiI4AzNwUjMwIjI0ICc8VkIsICdjVmavJHUgwWY63WblJFIn9WazN7byNEIsVmdlxkI0ISYONkIsUWdyRnOiwmdFJCLiEDN4gTNzMTO6kTN4YTN9IiOiQWSiwSfdJCdlVGaTRncvBXZSJCLiQnchh6QhRXYEJCLiUGbiFGV43mdpBlIsICdlVGaTRHduF6RislOicGbmJCLlNHbhZmOiI7ckJye0ICbuFkI1pjIEJCLi4TP7FlchJFOxJlaXp7UVpVN6F6cYBDWYtWTPhXO8lXVu9URvsWa0Zzc6tyb4dVSCl6T8BzY6oXM9dmcuJ5K5YTUMZdc";
//const COLUMN_COUNT = 12;
const GROUP1_COLOR = '#cce0ff';
const GROUP2_COLOR = '#D6E5C9';
const GROUP3_COLOR = '#fff2cc';
const LINE_ITEM_COLOR = '#ffffff';
const SUBTOTAL_COLOR = '#F5F3E7';
const GROUP1_SUBTOTAL_COLOR = "#d6f5d6";
const GROUP2_SUBTOTAL_COLOR = "#fce4d6";
const TOTAL_COLOR = '#c6e0b4';
//const COL_TOTAL_COUNT = 25;
// Replace these constants:
const START_YEAR = 2015;
const START_MONTH = 0; // 0-based: Dec
const END_YEAR = 2036;
const END_MONTH = 5; // 0-based: June


// Generate month headers from Dec 2021 to Jun 2036
const generateMonthHeaders = () => {
    const headers = [];
    let date = new Date(START_YEAR, START_MONTH);
    const endDate = new Date(END_YEAR, END_MONTH + 1); // Inclusive of June 2036
    while (date < endDate) {
        headers.push(`${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear().toString().slice(2)}`);
        date.setMonth(date.getMonth() + 1);
    }
    return headers;
};

const MONTH_HEADERS = generateMonthHeaders();
const COLUMN_COUNT = MONTH_HEADERS.length + 4; // Expense Type + Comment
const COL_TOTAL_COUNT = COLUMN_COUNT;

// Import the types for style if available, or use any if not
// Assuming you have access to GC.Spread.Sheets.Style type

// Define allowed levels as a union type
type Level =
    | 'Group1'
    | 'Group2'
    | 'Group3'
    | 'LineItem'
    | 'Subtotal'
    | 'Group2Subtotal'
    | 'Group1Subtotal'
    | 'Total';

// Map level to Style objects
const stylesByLevel: Record<Level, GC.Spread.Sheets.Style> = {} as any;
const col0StylesByLevel: Record<Level, GC.Spread.Sheets.Style> = {} as any;

const levelList: Level[] = [
    'Group1',
    'Group2',
    'Group3',
    'LineItem',
    'Subtotal',
    'Group2Subtotal',
    'Group1Subtotal',
    'Total',
];

// Colors map
const bgColorMap: Record<Level, string> = {
    Group1: GROUP1_COLOR,
    Group2: GROUP2_COLOR,
    Group3: GROUP3_COLOR,
    LineItem: LINE_ITEM_COLOR,
    Subtotal: SUBTOTAL_COLOR,
    Group1Subtotal: GROUP1_SUBTOTAL_COLOR,
    Group2Subtotal: GROUP2_SUBTOTAL_COLOR,
    Total: TOTAL_COLOR,
};

levelList.forEach((level) => {
    const style = new GC.Spread.Sheets.Style();
    style.backColor = bgColorMap[level];
    style.hAlign = GC.Spread.Sheets.HorizontalAlign.center;

    if (level === 'Group1') style.font = 'bold 14px Segoe UI';
    else if (level === 'Group2') style.font = 'bold 13px Segoe UI';
    else if (level === 'Group3') style.font = 'bold 12px Segoe UI';
    else if (['Subtotal', 'Group2Subtotal', 'Group1Subtotal', 'Total'].includes(level))
        style.font = 'bold 12px Segoe UI';

    stylesByLevel[level] = style;

    const col0Style = new GC.Spread.Sheets.Style();
    col0Style.hAlign = GC.Spread.Sheets.HorizontalAlign.left;
    col0Style.wordWrap = true;
    if (level === 'Group1') col0Style.cellPadding = '0 0 0 10';
    else if (level === 'Group2') col0Style.cellPadding = '0 0 0 10';
    else if (level === 'Group3') col0Style.cellPadding = '0 0 0 20';
    else if (level === 'LineItem') col0Style.cellPadding = '0 0 0 30';
    else if (['Subtotal', 'Group2Subtotal', 'Group1Subtotal', 'Total'].includes(level))
        col0Style.cellPadding = '0 0 0 10';

    col0StylesByLevel[level] = col0Style;
});

const SpreadClient = () => {
    const spreadRef = useRef<{ workbook: GC.Spread.Sheets.Workbook } | null>(null);



    const [spreadReady, setSpreadReady] = useState(false);
    useEffect(() => {
        const spread = spreadRef.current?.workbook;
        if (!spread) return;


        //spread.options.highlightFrozenPane = false;
        spread.options.tabStripVisible = false;
        spread.options.referenceStyle = GC.Spread.Sheets.ReferenceStyle.r1c1;
        const sheet = spread.getActiveSheet();
        if (!sheet) return;
        sheet.frozenRowCount(1);     // Freezes header
        sheet.frozenColumnCount(4);
        sheet.options.frozenlineColor = 'transparent';
        /* server fetch*/

        /*end*/

        sheet.setRowCount(52, GC.Spread.Sheets.SheetArea.viewport);
        sheet.setColumnCount(COL_TOTAL_COUNT, GC.Spread.Sheets.SheetArea.viewport);
        sheet.suspendPaint();

        //sheet.setRowCount(500);
        //sheet.setColumnCount(COLUMN_COUNT);

        // Set column headers
        const headers = ['Work Category', 'Quantity', 'Unit', 'Rate', ...MONTH_HEADERS];
        headers.forEach((h, idx) => sheet.setValue(0, idx, h));


        sheet.getRange(0, 0, 1, COLUMN_COUNT).font('bold 12px Segoe UI');
        sheet.getRange(0, 0, 1, COLUMN_COUNT).backColor('#d9d9d9');
        sheet.getRange(0, 0, 1, COLUMN_COUNT).hAlign(GC.Spread.Sheets.HorizontalAlign.center);

        const frozenHeaderStyle = new GC.Spread.Sheets.Style();
        frozenHeaderStyle.backColor = '#7e57c2  ';
        frozenHeaderStyle.foreColor = '#fff'; // Darker text
        frozenHeaderStyle.font = 'bold 12px Segoe UI';
        frozenHeaderStyle.hAlign = GC.Spread.Sheets.HorizontalAlign.center;

        // Add borders to top, bottom, and right to visually isolate the frozen area
        const headerBorder = new GC.Spread.Sheets.LineBorder('#b0b0b0', GC.Spread.Sheets.LineStyle.thin);
        frozenHeaderStyle.borderTop = headerBorder;
        frozenHeaderStyle.borderBottom = headerBorder;
        frozenHeaderStyle.borderRight = headerBorder;

        sheet.getRange(0, 0, 1, 4).setStyle(frozenHeaderStyle);
        // Set column widths
        sheet.setColumnWidth(0, 300); // Expense Type
        for (let i = 1; i <= MONTH_HEADERS.length; i++) {
            sheet.setColumnWidth(i, 120); // Monthly columns
        }
        //sheet.setColumnWidth(COLUMN_COUNT - 1, COMMENT_COL_WIDTH);
        sheet.getRange(1, 0, sheet.getRowCount() - 1, 1).wordWrap(true);

        const borderStyle = new GC.Spread.Sheets.LineBorder('black', GC.Spread.Sheets.LineStyle.thin);
        const sampleData = [
            , { level: "Group1", label: "1 Test Data June" }
            , { level: "Group2", label: "1.1 Test Data June Escalation" }
            , {
                level: "Group3", label: "1 Test Data June Risk"
            }
            , { level: 'Subtotal', label: 'Sub-total 1 Test Data June Risk' },
            , { level: "LineItem", label: " Test Data June Risk and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] }
            , { level: "Group3", label: "Test Data 1 May Risk" }
            , { level: "LineItem", label: "Test Data May and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] },
            , { level: 'Subtotal', label: 'Sub-total Test Data 1 May Risk' },
            , { level: 'Group2Subtotal', label: 'Sub-total 1.1 Test Data June Escalation' },
            , { level: 'Group1Subtotal', label: 'Sub-total 1 Test Data June , Escalation' },
            , { level: "Group1", label: "2 Test Data June" }
            , { level: "Group2", label: "2.1 Test Data June Escalation" }
            , {
                level: "Group3", label: "2 Test Data June Risk"
            }
            , { level: 'Subtotal', label: 'Sub-total 2 Test Data June Risk' },
            , { level: "LineItem", label: "Test Data June Risk and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] }
            , { level: "Group3", label: "Test Data 2 May Risk" }
            , { level: "LineItem", label: "Test Data May and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] },
            , { level: 'Subtotal', label: 'Sub-total Test Data 1 May Risk' },
            , { level: 'Group2Subtotal', label: 'Sub-total 2.1 Test Data June Escalation' },
            , { level: 'Group1Subtotal', label: 'Sub-total 2.1 Test Data June , Escalation' },
            , { level: "Group1", label: "1 Test Data June" }
            , { level: "Group2", label: "1.1 Test Data June Escalation" }
            , {
                level: "Group3", label: "3 Test Data June Risk"
            }
            , { level: 'Subtotal', label: 'Sub-total 3 Test Data June Risk' },
            , { level: "LineItem", label: " Test Data June Risk and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] }
            , { level: "Group3", label: "Test Data 3 May Risk" }
            , { level: "LineItem", label: "Test Data May and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] },
            , { level: 'Subtotal', label: 'Sub-total Test Data 1 May Risk' },
            , { level: 'Group2Subtotal', label: 'Sub-total 3.1 Test Data June Escalation' },
            , { level: 'Group1Subtotal', label: 'Sub-total 3 Test Data June , Escalation' },
            , { level: "Group1", label: "4 Test Data June" }
            , { level: "Group2", label: "4.1 Test Data June Escalation" }
            , {
                level: "Group3", label: "4 Test Data June Risk"
            }
            , { level: 'Subtotal', label: 'Sub-total 4 Test Data June Risk' },
            , { level: "LineItem", label: " Test Data June Risk and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] }
            , { level: "Group3", label: "Test Data 4 May Risk" }
            , { level: "LineItem", label: "Test Data May and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] },
            , { level: 'Subtotal', label: 'Sub-total Test Data 1 May Risk' },
            , { level: 'Group2Subtotal', label: 'Sub-total 4.1 Test Data June Escalation' },
            , { level: 'Group1Subtotal', label: 'Sub-total 4 Test Data June , Escalation' },
            , { level: "Group1", label: "5 Test Data June" }
            , { level: "Group2", label: "5.1 Test Data June Escalation" }
            , {
                level: "Group3", label: "Test Data June Risk" }
            , { level: 'Subtotal', label: 'Sub-total Test Data June Risk' },
            , { level: "LineItem", label: " Test Data June Risk and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] }
            , { level: "Group3", label: "Test Data May Risk" }
            , { level: "LineItem", label: "Test Data May and Opportunities", quantity: 10, "unit": "m2", rate: 1000, values: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] },
            , { level: 'Subtotal', label: 'Sub-total Test Data May Risk' },
            , { level: 'Group2Subtotal', label: 'Sub-total 5.1 Test Data June Escalation' },
            , { level: 'Group1Subtotal', label: 'Sub-total 5 Test Data June , Escalation' },
            , { level: 'Total', label: 'TOTAL' }
        ];


        const data = sampleData;// generateSampleData();
        let currentRow = 1;

        const subtotalIndexes: number[] = [];
        const group2SubtotalIndexes: number[] = [];
        const group1SubtotalIndexes: number[] = [];
        const group3Indexes = [];
        const lineItemIndexes = [];
        let totalRow: number | null = null;
        const dataIndexToSheetRow = new Map<number, number>();
        function findPreviousBreakRow(currentSubtotalSheetRow: number) {
            let matchingGroup3SheetRow = -1;

            for (let i = 0; i < data.length; i++) {
                const sheetRow = dataIndexToSheetRow.get(i);
                if (sheetRow !== undefined && sheetRow < currentSubtotalSheetRow && data[i]?.level === 'Group3') {
                    matchingGroup3SheetRow = sheetRow;
                }
            }

            return matchingGroup3SheetRow;
        }
        function findPreviousGroup1BreakRow(currentGroup1SubtotalSheetRow: number) {
            let matchingGroup1SheetRow = -1;

            for (let i = 0; i < data.length; i++) {
                const sheetRow = dataIndexToSheetRow.get(i);
                if (sheetRow !== undefined && sheetRow < currentGroup1SubtotalSheetRow && data[i]?.level === 'Group1') {
                    matchingGroup1SheetRow = sheetRow;
                }
            }

            return matchingGroup1SheetRow;
        }

        function findPreviousGroup2BreakRow(currentSheetRow: number): number {
            let matchingGroup2Row = -1;

            for (let i = 0; i < data.length; i++) {
                const sheetRow = dataIndexToSheetRow.get(i);
                if (sheetRow !== undefined && sheetRow < currentSheetRow && data[i]?.level === 'Group2') {
                    matchingGroup2Row = sheetRow;
                }
            }

            return matchingGroup2Row;
        }

        data.forEach((item, idx) => {
            if (!item) return;
            const level = item.level as Level;
            dataIndexToSheetRow.set(idx, currentRow);

            const { label, quantity, unit, rate, values } = item;

            if (level === 'Subtotal') subtotalIndexes.push(currentRow);
            else if (level === 'Group3') group3Indexes.push(idx);
            else if (level === 'LineItem') lineItemIndexes.push(idx);
            else if (level === 'Group2Subtotal') group2SubtotalIndexes.push(currentRow);
            else if (level === 'Group1Subtotal') group1SubtotalIndexes.push(currentRow);
            else if (level === 'Total') totalRow = currentRow;

            sheet.setValue(currentRow, 0, label);
            sheet.setValue(currentRow, 1, quantity ?? '');
            sheet.setValue(currentRow, 2, unit ?? '');
            sheet.setValue(currentRow, 3, rate ?? '');

            if (level === 'LineItem') {
                const cutoffIndex = MONTH_HEADERS.findIndex(header => header === 'Dec 28');
                const fullValues = Array.from({ length: MONTH_HEADERS.length }, (_, i) =>
                    i < cutoffIndex ? (values?.[i] ?? '') : 0
                );
                sheet.setArray(currentRow, 4, [fullValues]);
            }

            // Apply the cached styles
            sheet.setStyle(currentRow, -1, stylesByLevel[level]);
            sheet.setStyle(currentRow, 0, col0StylesByLevel[level]);

            // Set row height for Group1 only
            if (level === 'Group1') {
                sheet.setRowHeight(currentRow, 40);
            }

            // Apply border to each cell
            for (let c = 0; c < COL_TOTAL_COUNT; c++) {
                sheet.getCell(currentRow, c).borderLeft(borderStyle);
                sheet.getCell(currentRow, c).borderRight(borderStyle);
                sheet.getCell(currentRow, c).borderTop(borderStyle);
                sheet.getCell(currentRow, c).borderBottom(borderStyle);
            }

            currentRow++;
        });

        subtotalIndexes.forEach((subtotalRow) => {
            const breakRow = findPreviousBreakRow(subtotalRow);
            //if (index < 2) {
            //    console.log(`Subtotal Row: ${subtotalRow}, Break Row: ${breakRow}`);
            //}
            // LineItems between breakRow + 1 and subtotalRow - 1
            const startRow = breakRow + 1;
            const endRow = subtotalRow - 1;

            for (let col = 4; col < COLUMN_COUNT; col++) {
                if (startRow <= endRow) {
                    // Use range notation, faster than multiple cells
                    const formula = `=SUM(R${startRow + 1}C${col + 1}:R${endRow + 1}C${col + 1})`;
                    sheet.setFormula(subtotalRow, col, formula);
                } else {
                    // No line items to sum, set zero or empty
                    sheet.setValue(subtotalRow, col, 0);
                }
            }
        });
        group2SubtotalIndexes.forEach((group2SubtotalRow, index) => {
            const breakRow = findPreviousGroup2BreakRow(group2SubtotalRow);
            if (index < 2) {
                console.log(`Group2Subtotal Row: ${group2SubtotalRow}, Break Row: ${breakRow}`);
            }

            // Collect subtotal rows between breakRow and group2SubtotalRow
            const subtotalsToSum = subtotalIndexes.filter(
                row => row > breakRow && row < group2SubtotalRow
            );

            for (let col = 4; col < COLUMN_COUNT; col++) {
                if (subtotalsToSum.length > 0) {
                    const formula = `=SUM(${subtotalsToSum.map(r => `R${r + 1}C${col + 1}`).join(',')})`;
                    sheet.setFormula(group2SubtotalRow, col, formula);
                } else {
                    sheet.setValue(group2SubtotalRow, col, 0);
                }
            }
        });
        group1SubtotalIndexes.forEach(group1SubtotalRow => {
            const breakRow = findPreviousGroup1BreakRow(group1SubtotalRow);
            const group2SubtotalRowsToSum = group2SubtotalIndexes.filter(r => r > breakRow && r < group1SubtotalRow);

            for (let col = 4; col < COLUMN_COUNT; col++) {
                if (group2SubtotalRowsToSum.length > 0) {
                    const formula = `=SUM(${group2SubtotalRowsToSum.map(r => `R${r + 1}C${col + 1}`).join(',')})`;
                    sheet.setFormula(group1SubtotalRow, col, formula);
                } else {
                    sheet.setValue(group1SubtotalRow, col, 0);
                }
            }
        });

        if (totalRow !== null) {
            for (let col = 4; col < COLUMN_COUNT; col++) {
                if (group1SubtotalIndexes.length > 0) {
                    const formula = `=SUM(${group1SubtotalIndexes.map(r => `R${r + 1}C${col + 1}`).join(',')})`;
                    sheet.setFormula(totalRow, col, formula);
                } else {
                    sheet.setValue(totalRow, col, 0);
                }
            }
        }



        sheet.resumePaint();

    }, []);




    return (
        <div className={styles.sampleTutorial}>
            <div className={styles.sampleSpreadsheets}>
                {!spreadReady && <CircularProgress />}
                <SpreadSheets
                    workbookInitialized={(wb) => {
                        spreadRef.current = { workbook: wb };
                        setSpreadReady(true);
                    }}
                />
            </div>
        </div>

       
    )
};

export default SpreadClient;
